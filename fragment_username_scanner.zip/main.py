"""
Entrypoint.

Usage:
    python main.py                  # run bot + background scan loop
    python main.py --scan-once      # run a single scan cycle and exit (no bot)

Required environment variables (put them in a .env file or export them):
    FRAGMENT_SCANNER_BOT_TOKEN   — Telegram bot token from @BotFather
    FRAGMENT_SCANNER_CHAT_ID     — chat/channel id to notify
    ANTHROPIC_API_KEY            — only needed if ai_analysis.enabled: true
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os

from scanner.ai_analyzer import AiAnalyzer
from scanner.bot import ScannerBot
from scanner.config import load_config
from scanner.db import ScannerDB
from scanner.dictionary import load_dictionary
from scanner.pipeline import run_scan_cycle

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("main")


async def background_scan_loop(config, dictionary, db, ai, bot: ScannerBot | None):
    interval = config.source.get("poll_interval_seconds", 120)
    while True:
        try:
            examined = await run_scan_cycle(config, dictionary, db, ai)
            logger.info("Background scan examined %d listings.", examined)
            if bot:
                await bot.notify_new_candidates()
        except Exception:
            logger.exception("Background scan cycle failed; will retry next interval.")
        await asyncio.sleep(interval)


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None, help="Path to config.yaml")
    parser.add_argument("--scan-once", action="store_true", help="Run a single scan cycle and exit")
    args = parser.parse_args()

    config = load_config(args.config) if args.config else load_config()

    dictionary = load_dictionary(config.dictionary_sources)
    logger.info("Loaded dictionary: %d total entries across %d source files.",
                dictionary.total_words, len(config.dictionary_sources))

    db = ScannerDB(config.database_path)

    ai = None
    if config.ai_analysis.get("enabled"):
        ai = AiAnalyzer(config.ai_analysis, config.anthropic_api_key, db)
        if not ai.enabled:
            logger.warning("AI analysis enabled in config but ANTHROPIC_API_KEY is missing — "
                            "falling back to deterministic scoring only.")

    if args.scan_once:
        examined = await run_scan_cycle(config, dictionary, db, ai)
        logger.info("Single scan complete: %d listings examined.", examined)
        top = db.get_top(limit=20, min_score=config.scoring["thresholds"]["interesting"])
        for row in top:
            print(f"{row['final_score']:>5.0f}  @{row['username']:<20}  {row['det_category']:<12}  {row['det_matched_word']}")
        if ai:
            await ai.close()
        db.close()
        return

    bot_token = config.telegram_bot_token
    chat_id = config.telegram_chat_id
    bot = None
    tasks = []

    if config.notifications["telegram"]["enabled"] and bot_token and chat_id:
        async def _run_scan():
            return await run_scan_cycle(config, dictionary, db, ai)

        bot = ScannerBot(
            token=bot_token,
            chat_id=chat_id,
            db=db,
            notif_cfg=config.notifications["telegram"],
            run_scan_cycle=_run_scan,
        )
        tasks.append(asyncio.create_task(bot.run()))
    else:
        logger.warning("Telegram bot not started (missing token/chat id or disabled in config). "
                        "Running scan loop only; use --scan-once to inspect results via stdout.")

    tasks.append(asyncio.create_task(background_scan_loop(config, dictionary, db, ai, bot)))

    try:
        await asyncio.gather(*tasks)
    finally:
        if ai:
            await ai.close()
        db.close()


if __name__ == "__main__":
    asyncio.run(main())
