"""
Fetches the dwyl/english-words wordlist (~370k+ English words, MIT
licensed, free — the standard bulk alternative since there is no official
Google dictionary API/dataset) and writes it into data/wordlist_en.txt in
the one-word-per-line format the scanner's dictionary loader expects.

This REPLACES the small curated starter list with a comprehensive one.
Re-run any time you want to refresh it.

Usage:
    python scripts/fetch_full_wordlist.py
    python scripts/fetch_full_wordlist.py --max-length 24   # optional cap
"""

from __future__ import annotations

import argparse
import pathlib
import re
import sys
import urllib.request

SOURCE_URL = (
    "https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt"
)
OUTPUT_PATH = pathlib.Path(__file__).resolve().parent.parent / "data" / "wordlist_en.txt"
WORD_RE = re.compile(r"^[a-z]+$")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-length", type=int, default=32,
                         help="Drop words longer than this (matches scoring.max_length_considered by default)")
    parser.add_argument("--min-length", type=int, default=2)
    parser.add_argument("--url", default=SOURCE_URL)
    args = parser.parse_args()

    print(f"Fetching {args.url} ...")
    try:
        req = urllib.request.Request(args.url, headers={"User-Agent": "FragmentUsernameScanner/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        print(f"Download failed: {e}", file=sys.stderr)
        print("If you're offline or the URL moved, download words_alpha.txt manually from "
              "https://github.com/dwyl/english-words and pass its local path via --url file://<path>",
              file=sys.stderr)
        sys.exit(1)

    words = set()
    for line in raw.splitlines():
        w = line.strip().lower()
        if args.min_length <= len(w) <= args.max_length and WORD_RE.match(w):
            words.add(w)

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        for w in sorted(words):
            f.write(w + "\n")

    print(f"Wrote {len(words):,} words to {OUTPUT_PATH}")
    print("Restart the scanner (or it will reload on next start, per dictionary.reload_on_start) to pick it up.")


if __name__ == "__main__":
    main()
