"""
One-shot entrypoint for scheduled hosting (GitHub Actions, cron, etc.):
run a single scan cycle, send any new above-threshold candidates to
Telegram, mark them notified, then exit. No long-running process, no
/scan or /top commands — this is the "no live commands" tradeoff of
running on a scheduler instead of an always-on host.

Reads the same config.yaml as main.py. Credentials come from environment
variables (GitHub Actions injects these from repo secrets):
    FRAGMENT_SCANNER_BOT_TOKEN
    FRAGMENT_SCANNER_CHAT_ID
"""

from __future__ import annotations

import asyncio
import logging

from scanner.config import load_config
from scanner.db import ScannerDB
from scanner.dictionary import load_dictionary
from scanner.notify_formatting import fmt_compact_line, fmt_full_card
from scanner.pipeline import run_scan_cycle
from scanner.telegram_http import send_telegram_message

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("scan_and_notify")


async def main() -> None:
    config = load_config()
    dictionary = load_dictionary(config.dictionary_sources)
    db = ScannerDB(config.database_path)

    # AI analysis stays off here regardless of config.yaml, to guarantee
    # this scheduled path never silently incurs API costs.
    ai = None

    examined = await run_scan_cycle(config, dictionary, db, ai)
    logger.info("Scan complete: %d listings examined.", examined)

    notif_cfg = config.notifications["telegram"]
    token = config.telegram_bot_token
    chat_id = config.telegram_chat_id

    if not (notif_cfg.get("enabled") and token and chat_id):
        logger.warning("Telegram not configured (missing token/chat id, or disabled) — skipping notification step.")
        db.close()
        return

    min_score = notif_cfg["min_score_to_notify"]
    max_results = notif_cfg["max_results_per_notification"]
    list_threshold = notif_cfg.get("list_mode_threshold", 5)

    rows = db.get_unnotified_above(min_score)[:max_results]
    if not rows:
        logger.info("No new candidates above threshold — nothing to notify.")
        db.close()
        return

    if len(rows) > list_threshold:
        text = "\n".join(fmt_compact_line(r) for r in rows)
        ok = await send_telegram_message(token, chat_id, text)
        sent_all = ok
    else:
        sent_all = True
        for row in rows:
            ok = await send_telegram_message(token, chat_id, fmt_full_card(row))
            sent_all = sent_all and ok
            await asyncio.sleep(0.5)  # be polite to Telegram's rate limits too

    if sent_all:
        db.mark_notified([(r["username"], r["final_score"]) for r in rows])
        logger.info("Notified %d candidate(s).", len(rows))
    else:
        logger.warning("Some notifications failed to send — leaving them unmarked so they're retried next run.")

    db.close()


if __name__ == "__main__":
    asyncio.run(main())
