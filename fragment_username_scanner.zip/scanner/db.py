"""
SQLite persistence layer.

Tables:
  candidates    — every auction listing seen, with latest score/status
  ai_cache      — cached AI semantic-check results, keyed by username
  scan_state    — small key/value table (e.g. last_scan_ts, cursor/page state)
  notified      — usernames already sent in a Telegram notification, so we
                  never re-notify unless the underlying listing meaningfully
                  changed (price/status)
"""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (
    username        TEXT PRIMARY KEY,
    length          INTEGER NOT NULL,
    auction_status  TEXT,
    price_ton       REAL,
    price_usd       REAL,
    time_left       TEXT,
    listing_url     TEXT,
    first_seen_ts   REAL NOT NULL,
    last_seen_ts    REAL NOT NULL,
    det_score       REAL,
    det_tier        TEXT,
    det_category    TEXT,
    det_matched_word TEXT,
    det_reasons     TEXT,
    ai_score        REAL,
    ai_meaning      TEXT,
    ai_why          TEXT,
    final_score     REAL,
    final_tier      TEXT,
    raw_json        TEXT
);

CREATE INDEX IF NOT EXISTS idx_candidates_final_score
    ON candidates(final_score DESC);

CREATE TABLE IF NOT EXISTS ai_cache (
    username    TEXT PRIMARY KEY,
    result_json TEXT NOT NULL,
    created_ts  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS scan_state (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS notified (
    username     TEXT PRIMARY KEY,
    notified_ts  REAL NOT NULL,
    score_at_time REAL
);
"""


class ScannerDB:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._path = path
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    @contextmanager
    def cursor(self) -> Iterator[sqlite3.Cursor]:
        cur = self._conn.cursor()
        try:
            yield cur
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise
        finally:
            cur.close()

    # ---- candidates ----------------------------------------------------
    def upsert_candidate(self, data: dict[str, Any]) -> None:
        now = time.time()
        with self.cursor() as cur:
            cur.execute("SELECT first_seen_ts FROM candidates WHERE username = ?", (data["username"],))
            row = cur.fetchone()
            first_seen = row["first_seen_ts"] if row else now
            cur.execute(
                """
                INSERT INTO candidates (
                    username, length, auction_status, price_ton, price_usd,
                    time_left, listing_url, first_seen_ts, last_seen_ts,
                    det_score, det_tier, det_category, det_matched_word,
                    det_reasons, ai_score, ai_meaning, ai_why, final_score,
                    final_tier, raw_json
                ) VALUES (
                    :username, :length, :auction_status, :price_ton, :price_usd,
                    :time_left, :listing_url, :first_seen_ts, :last_seen_ts,
                    :det_score, :det_tier, :det_category, :det_matched_word,
                    :det_reasons, :ai_score, :ai_meaning, :ai_why, :final_score,
                    :final_tier, :raw_json
                )
                ON CONFLICT(username) DO UPDATE SET
                    length=excluded.length,
                    auction_status=excluded.auction_status,
                    price_ton=excluded.price_ton,
                    price_usd=excluded.price_usd,
                    time_left=excluded.time_left,
                    listing_url=excluded.listing_url,
                    last_seen_ts=excluded.last_seen_ts,
                    det_score=excluded.det_score,
                    det_tier=excluded.det_tier,
                    det_category=excluded.det_category,
                    det_matched_word=excluded.det_matched_word,
                    det_reasons=excluded.det_reasons,
                    ai_score=COALESCE(excluded.ai_score, candidates.ai_score),
                    ai_meaning=COALESCE(excluded.ai_meaning, candidates.ai_meaning),
                    ai_why=COALESCE(excluded.ai_why, candidates.ai_why),
                    final_score=excluded.final_score,
                    final_tier=excluded.final_tier,
                    raw_json=excluded.raw_json
                """,
                {
                    **data,
                    "first_seen_ts": first_seen,
                    "last_seen_ts": now,
                },
            )

    def get_top(self, limit: int = 20, min_score: float = 0.0) -> list[sqlite3.Row]:
        with self.cursor() as cur:
            cur.execute(
                """
                SELECT * FROM candidates
                WHERE final_score >= ?
                ORDER BY final_score DESC, last_seen_ts DESC
                LIMIT ?
                """,
                (min_score, limit),
            )
            return cur.fetchall()

    def get_unnotified_above(self, min_score: float) -> list[sqlite3.Row]:
        with self.cursor() as cur:
            cur.execute(
                """
                SELECT c.* FROM candidates c
                LEFT JOIN notified n ON c.username = n.username
                WHERE c.final_score >= ?
                  AND (n.username IS NULL OR n.score_at_time < c.final_score)
                ORDER BY c.final_score DESC
                """,
                (min_score,),
            )
            return cur.fetchall()

    def mark_notified(self, usernames_scores: list[tuple[str, float]]) -> None:
        now = time.time()
        with self.cursor() as cur:
            cur.executemany(
                """
                INSERT INTO notified (username, notified_ts, score_at_time)
                VALUES (?, ?, ?)
                ON CONFLICT(username) DO UPDATE SET
                    notified_ts=excluded.notified_ts,
                    score_at_time=excluded.score_at_time
                """,
                [(u, now, s) for u, s in usernames_scores],
            )

    # ---- ai cache --------------------------------------------------------
    def get_ai_cache(self, username: str) -> dict[str, Any] | None:
        with self.cursor() as cur:
            cur.execute("SELECT result_json FROM ai_cache WHERE username = ?", (username,))
            row = cur.fetchone()
            return json.loads(row["result_json"]) if row else None

    def set_ai_cache(self, username: str, result: dict[str, Any]) -> None:
        with self.cursor() as cur:
            cur.execute(
                """
                INSERT INTO ai_cache (username, result_json, created_ts)
                VALUES (?, ?, ?)
                ON CONFLICT(username) DO UPDATE SET
                    result_json=excluded.result_json, created_ts=excluded.created_ts
                """,
                (username, json.dumps(result), time.time()),
            )

    # ---- scan state --------------------------------------------------------
    def get_state(self, key: str, default: str | None = None) -> str | None:
        with self.cursor() as cur:
            cur.execute("SELECT value FROM scan_state WHERE key = ?", (key,))
            row = cur.fetchone()
            return row["value"] if row else default

    def set_state(self, key: str, value: str) -> None:
        with self.cursor() as cur:
            cur.execute(
                """
                INSERT INTO scan_state (key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value
                """,
                (key, value),
            )

    def close(self) -> None:
        self._conn.close()
