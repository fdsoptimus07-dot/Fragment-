"""
AI semantic-check stage.

Deliberately the LAST and most expensive stage of the pipeline — it only
ever sees usernames that already cleared `min_deterministic_score_for_ai`.
Results are cached in SQLite (keyed by username) so a username is never
re-sent to the model once it's been evaluated, unless the cache is cleared.

Uses the Anthropic Messages API directly (no SDK dependency required).
Requires ANTHROPIC_API_KEY in the environment. If AI analysis is disabled
or the API key is missing, the pipeline simply falls back to the
deterministic score — nothing breaks.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import aiohttp

from .db import ScannerDB

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"

SYSTEM_PROMPT = (
    "You evaluate short strings as potential Telegram usernames for a "
    "collector marketplace. For each username, decide whether it carries "
    "real, recognizable meaning (a real word, common abbreviation, brand, "
    "name, or strong pattern) as opposed to being an arbitrary string. "
    "Respond ONLY with compact JSON, no prose, no markdown fences, matching "
    'exactly: {"has_meaning": bool, "meaning": string, "category": string, '
    '"semantic_score": number (0-100), "why": string (<=160 chars)}. '
    "category must be one of: dictionary_word, abbreviation, brand, name, "
    "crypto_tech_term, gaming_term, pattern, none. "
    "Be honest — if it's just a plausible-looking random string, say "
    "has_meaning: false and semantic_score low."
)


@dataclass
class AiResult:
    has_meaning: bool
    meaning: str
    category: str
    semantic_score: float
    why: str


class AiAnalyzer:
    def __init__(self, config: dict[str, Any], api_key: str | None, db: ScannerDB):
        self.enabled = config.get("enabled", False) and bool(api_key)
        self.model = config.get("model", "claude-sonnet-4-6")
        self.api_key = api_key
        self.db = db
        self.cache_results = config.get("cache_ai_results", True)
        self._session: aiohttp.ClientSession | None = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def analyze(self, username: str, deterministic_context: dict[str, Any]) -> AiResult | None:
        if not self.enabled:
            return None

        cached = self.db.get_ai_cache(username) if self.cache_results else None
        if cached:
            return AiResult(**cached)

        session = await self._ensure_session()
        user_prompt = (
            f'Username: "{username}"\n'
            f"Length: {len(username)}\n"
            f"Deterministic dictionary match: {deterministic_context.get('matched_word')}\n"
            f"Deterministic category guess: {deterministic_context.get('category')}\n"
        )
        payload = {
            "model": self.model,
            "max_tokens": 300,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": user_prompt}],
        }
        headers = {
            "x-api-key": self.api_key or "",
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        }
        try:
            async with session.post(ANTHROPIC_API_URL, json=payload, headers=headers, timeout=30) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
        except Exception:
            return None

        text_parts = [block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"]
        raw_text = "".join(text_parts).strip()
        raw_text = raw_text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()

        try:
            parsed = json.loads(raw_text)
            result = AiResult(
                has_meaning=bool(parsed.get("has_meaning", False)),
                meaning=str(parsed.get("meaning", ""))[:200],
                category=str(parsed.get("category", "none")),
                semantic_score=float(parsed.get("semantic_score", 0)),
                why=str(parsed.get("why", ""))[:200],
            )
        except (json.JSONDecodeError, TypeError, ValueError):
            return None

        if self.cache_results:
            self.db.set_ai_cache(username, result.__dict__)
        return result

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
