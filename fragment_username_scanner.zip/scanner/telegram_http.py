"""
Minimal Telegram Bot API client — just sendMessage, over raw HTTP via
aiohttp. Used by scripts/scan_and_notify.py so the GitHub Actions job
doesn't need the full python-telegram-bot dependency (which is only
needed for the live-polling /scan and /top commands in main.py).
"""

from __future__ import annotations

import asyncio

import aiohttp

API_BASE = "https://api.telegram.org"


async def send_telegram_message(token: str, chat_id: str, text: str) -> bool:
    """Sends one message. Returns True on success. Retries briefly on 429."""
    url = f"{API_BASE}/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": text}

    async with aiohttp.ClientSession() as session:
        backoff = 2.0
        for attempt in range(3):
            try:
                async with session.post(url, json=payload, timeout=15) as resp:
                    if resp.status == 200:
                        return True
                    if resp.status == 429:
                        data = await resp.json()
                        retry_after = data.get("parameters", {}).get("retry_after", backoff)
                        await asyncio.sleep(retry_after)
                        continue
                    body = await resp.text()
                    print(f"Telegram sendMessage failed ({resp.status}): {body}")
                    return False
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                print(f"Telegram sendMessage error, retrying: {e}")
                await asyncio.sleep(backoff)
                backoff *= 2
    return False
