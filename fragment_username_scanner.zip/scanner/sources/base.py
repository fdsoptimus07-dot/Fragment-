"""
Source adapter interface. The rest of the pipeline (scoring, DB, AI,
notifications) never talks to Fragment directly — it only talks to this
interface. Swap adapters by changing `source.adapter` in config.yaml and
registering the class in sources/__init__.py's ADAPTER_REGISTRY.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, AsyncIterator


@dataclass
class Listing:
    username: str
    length: int
    auction_status: str | None      # "auction" | "sale" | "sold" | "available" | None
    price_ton: float | None
    price_usd: float | None
    time_left: str | None
    listing_url: str | None
    raw: dict[str, Any]


class AuctionSource(ABC):
    """Abstract base for any place we pull username auction listings from."""

    def __init__(self, config: dict[str, Any]):
        self.config = config

    @abstractmethod
    async def fetch_listings(self, max_pages: int) -> AsyncIterator[Listing]:
        """Yield Listing objects for currently active (or recently listed)
        auctions/sales. Implementations must respect their own configured
        rate limits internally — callers should not need to throttle."""
        raise NotImplementedError

    @abstractmethod
    async def close(self) -> None:
        """Release any held connections/sessions."""
        raise NotImplementedError
