"""
Adapter for Fragment's publicly viewable username marketplace pages.

IMPORTANT — read before relying on this in production:

Fragment (fragment.com) does not publish an official, documented, public
API for auction data. This adapter therefore does the only thing that's
both possible and permitted without bypassing any protection: it fetches
the same HTML pages a logged-out visitor's browser would load
(fragment.com/usernames?...), at a conservative rate, and parses the
listing data out of that HTML. It does:

  - NO login / session / wallet connection
  - NO captcha solving or bypassing
  - NO private/internal endpoint guessing
  - a robots.txt check before crawling
  - a single configurable delay between requests plus a low concurrency cap
  - exponential backoff on 429/5xx responses, and it stops entirely
    (rather than retrying aggressively) if blocked

Because this relies on parsing public HTML rather than a stable documented
API, Fragment changing their page markup WILL break the parser. The
selectors below are written defensively (regex over known URL/text
patterns rather than brittle CSS classes) but you should expect to revisit
`_parse_listing_page` if scraped results start coming back empty — that's
a markup-change problem, not a logic bug, and no amount of retrying will
fix it.

If you have (or later obtain) access to a licensed/official data feed for
Fragment listings, write a new adapter implementing the same `AuctionSource`
interface and switch `source.adapter` in config.yaml — nothing else in the
pipeline needs to change.
"""

from __future__ import annotations

import asyncio
import re
import urllib.robotparser
from typing import Any, AsyncIterator
from urllib.parse import urljoin

import aiohttp

from .base import AuctionSource, Listing

# Matches /username/<name> links on listing pages.
USERNAME_LINK_RE = re.compile(r'href="(/username/([a-zA-Z0-9_]{3,32}))"')

# Matches a TON price like "1 234" or "1,234" near a listing, and a USD
# equivalent in parentheses/nearby span, when present in the surrounding
# HTML chunk we isolate per listing.
TON_PRICE_RE = re.compile(r'([\d][\d,\s]*(?:\.\d+)?)\s*(?:TON|💎)', re.IGNORECASE)
USD_PRICE_RE = re.compile(r'\$\s*([\d][\d,\s]*(?:\.\d+)?)')
TIME_LEFT_RE = re.compile(r'(\d+\s*(?:day|hour|minute|hr|min)s?[^<]{0,20})', re.IGNORECASE)
STATUS_HINTS = {
    "on auction": "auction",
    "auction": "auction",
    "for sale": "sale",
    "sold": "sold",
}


class FragmentPublicHtmlSource(AuctionSource):
    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.base_url = config["base_url"].rstrip("/")
        self.delay = float(config.get("request_delay_seconds", 2.5))
        self.max_concurrent = int(config.get("max_concurrent_requests", 2))
        self.timeout = aiohttp.ClientTimeout(total=config.get("request_timeout_seconds", 15))
        self.user_agent = config.get("user_agent", "FragmentUsernameScanner/1.0")
        self.respect_robots = config.get("respect_robots_txt", True)
        self._session: aiohttp.ClientSession | None = None
        self._semaphore = asyncio.Semaphore(self.max_concurrent)
        self._robots_checked = False
        self._robots_allowed = True

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            headers = {"User-Agent": self.user_agent}
            self._session = aiohttp.ClientSession(headers=headers, timeout=self.timeout)
        return self._session

    async def _check_robots(self) -> bool:
        if not self.respect_robots:
            return True
        if self._robots_checked:
            return self._robots_allowed
        self._robots_checked = True
        try:
            session = await self._ensure_session()
            async with session.get(f"{self.base_url}/robots.txt") as resp:
                text = await resp.text() if resp.status == 200 else ""
            rp = urllib.robotparser.RobotFileParser()
            rp.parse(text.splitlines())
            self._robots_allowed = rp.can_fetch(self.user_agent, f"{self.base_url}/usernames")
        except Exception:
            # If robots.txt can't be fetched/parsed, default to conservative
            # crawling (allowed) but keep the delay + concurrency limits —
            # matches standard practice, since no robots.txt is not a
            # disallow signal.
            self._robots_allowed = True
        return self._robots_allowed

    async def _get(self, url: str) -> str | None:
        session = await self._ensure_session()
        backoff = self.delay
        for attempt in range(4):
            async with self._semaphore:
                try:
                    async with session.get(url) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            await asyncio.sleep(self.delay)
                            return text
                        if resp.status == 429:
                            await asyncio.sleep(backoff)
                            backoff *= 2
                            continue
                        if resp.status >= 500:
                            await asyncio.sleep(backoff)
                            backoff *= 2
                            continue
                        # 4xx other than 429: don't hammer it, give up on this URL
                        return None
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    await asyncio.sleep(backoff)
                    backoff *= 2
        return None

    def _parse_listing_page(self, html: str) -> list[Listing]:
        """Defensive, regex-based extraction. See module docstring for why
        this isn't CSS-selector based."""
        listings: dict[str, Listing] = {}
        for match in USERNAME_LINK_RE.finditer(html):
            href, username = match.group(1), match.group(2)
            # isolate a window of HTML around this link to look for the
            # price/status/time-left that Fragment renders alongside it
            start = match.start()
            window = html[start:start + 600]

            status = None
            lower_window = window.lower()
            for hint, val in STATUS_HINTS.items():
                if hint in lower_window:
                    status = val
                    break

            ton_match = TON_PRICE_RE.search(window)
            usd_match = USD_PRICE_RE.search(window)
            time_match = TIME_LEFT_RE.search(window)

            def _to_float(s: str | None) -> float | None:
                if not s:
                    return None
                try:
                    return float(s.replace(",", "").replace(" ", ""))
                except ValueError:
                    return None

            listing = Listing(
                username=username.lower(),
                length=len(username),
                auction_status=status,
                price_ton=_to_float(ton_match.group(1)) if ton_match else None,
                price_usd=_to_float(usd_match.group(1)) if usd_match else None,
                time_left=time_match.group(1).strip() if time_match else None,
                listing_url=urljoin(self.base_url + "/", href.lstrip("/")),
                raw={"source": "fragment_public_html"},
            )
            # de-dupe within a page (a username can appear more than once
            # in surrounding markup, e.g. nav + card)
            listings[username.lower()] = listing
        return list(listings.values())

    async def fetch_listings(self, max_pages: int) -> AsyncIterator[Listing]:
        allowed = await self._check_robots()
        if not allowed:
            # robots.txt disallows crawling this path — stop immediately.
            return

        for page in range(1, max_pages + 1):
            # Fragment's public listing page; ?page= is the conventional
            # pagination param. If Fragment changes this, update here only.
            url = f"{self.base_url}/usernames?filter=auction&sort=ending"
            if page > 1:
                url += f"&page={page}"

            html = await self._get(url)
            if not html:
                break

            page_listings = self._parse_listing_page(html)
            if not page_listings:
                # empty page — either we've paginated past the last page,
                # or the markup no longer matches our parser (see module
                # docstring). Either way, stop this cycle.
                break

            for listing in page_listings:
                yield listing

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
