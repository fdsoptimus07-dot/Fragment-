from __future__ import annotations

from typing import Any

from .base import AuctionSource, Listing
from .fragment_public_html import FragmentPublicHtmlSource

ADAPTER_REGISTRY: dict[str, type[AuctionSource]] = {
    "fragment_public_html": FragmentPublicHtmlSource,
}


def build_source(config: dict[str, Any]) -> AuctionSource:
    adapter_name = config["adapter"]
    cls = ADAPTER_REGISTRY.get(adapter_name)
    if cls is None:
        raise ValueError(
            f"Unknown source adapter '{adapter_name}'. "
            f"Available: {list(ADAPTER_REGISTRY)}. "
            "Register new adapters in scanner/sources/__init__.py."
        )
    return cls(config)


__all__ = ["AuctionSource", "Listing", "build_source", "ADAPTER_REGISTRY"]
