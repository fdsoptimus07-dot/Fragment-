"""
Deterministic scoring engine.

This runs on EVERY candidate username before any AI call is considered —
it's the fast filter stage. It never makes network calls.

Score is 0-100, composed of weighted sub-scores:
  - length_weight        (from config, big boost for 3-5 chars)
  - dictionary_match     (exact word / abbreviation / compound match)
  - semantic_meaning     (heuristic proxy pre-AI; AI can refine later)
  - pronounceability     (vowel/consonant pattern heuristic)
  - rarity               (inverse of "how generic" the term is)
  - pattern_quality      (repeats, palindromes, clean CV alternation)
  - brandability          (short, pronounceable, no digits, single word)
  - category_relevance   (crypto/tech/gaming/finance/brand bonus, weighted)

Also applies penalties for excessive numbers, unpronounceable clusters,
spammy patterns, and (best-effort) offensive terms.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .dictionary import Dictionary

VOWELS = set("aeiou")

# Best-effort static blocklist for obviously offensive terms. This is not
# exhaustive; treat it as a floor, not a substitute for human review before
# any external action is taken on a flagged candidate.
OFFENSIVE_TERMS: set[str] = {
    # Intentionally left as a small illustrative set; extend privately
    # as needed. Kept minimal here to avoid the list itself becoming a
    # reference/lookup resource.
    "slur1_placeholder",
}

SPAMMY_PATTERNS = [
    re.compile(r"^(.)\1{3,}$"),          # aaaa, xxxxx
    re.compile(r"^\d+$"),                  # all digits
    re.compile(r"(.)\1{2,}"),             # 3+ repeated chars anywhere (soft signal)
]


@dataclass
class ScoreResult:
    username: str
    total_score: float
    breakdown: dict[str, float]
    category: str
    matched_word: str | None
    reasons: list[str] = field(default_factory=list)
    penalized: bool = False
    tier: str = "ignore"


def _length_score(length: int, cfg: dict[str, Any]) -> float:
    lw = cfg["length_weight"]
    if length <= 8:
        return float(lw.get(str(length), lw.get(length, 0)))
    return float(lw.get("9+", 0))


def _pronounceability_score(word: str) -> float:
    """Heuristic: penalize long consonant/vowel runs and unpronounceable
    clusters; reward clean alternation and reasonable vowel ratio."""
    w = word.lower()
    if not w.isalpha():
        # strip non-letters for the pronounceability check only
        letters = re.sub(r"[^a-z]", "", w)
        if not letters:
            return 0.0
        w = letters

    vowel_count = sum(1 for c in w if c in VOWELS)
    ratio = vowel_count / len(w)

    # ideal vowel ratio roughly 0.3-0.55
    if 0.25 <= ratio <= 0.6:
        ratio_score = 1.0
    else:
        ratio_score = max(0.0, 1.0 - abs(ratio - 0.4) * 1.8)

    # penalize long consonant runs (4+ consecutive consonants)
    max_consonant_run = 0
    run = 0
    for c in w:
        if c not in VOWELS:
            run += 1
            max_consonant_run = max(max_consonant_run, run)
        else:
            run = 0
    run_penalty = 0.0
    if max_consonant_run >= 5:
        run_penalty = 0.6
    elif max_consonant_run == 4:
        run_penalty = 0.3

    score = max(0.0, ratio_score - run_penalty)
    return score  # 0..1


def _pattern_quality_score(word: str) -> tuple[float, list[str]]:
    """Rewards repeated-character motifs, palindromes, clean CV alternation.
    Returns (0..1 score, reasons)."""
    w = word.lower()
    reasons = []
    score = 0.0

    if w == w[::-1] and len(w) >= 3:
        score += 0.4
        reasons.append("palindrome")

    # clean alternating consonant/vowel pattern (very pronounceable, brandable)
    is_alpha = w.isalpha()
    if is_alpha and len(w) >= 3:
        pattern = "".join("V" if c in VOWELS else "C" for c in w)
        alternating = all(pattern[i] != pattern[i - 1] for i in range(1, len(pattern)))
        if alternating:
            score += 0.35
            reasons.append("clean CV alternation")

    # intentional repeated character (e.g. "coco", "zizi") as opposed to
    # spammy triple+ repeats
    for c in set(w):
        if w.count(c) >= 2 and len(w) <= 6:
            score += 0.15
            reasons.append("repeated-character motif")
            break

    return min(score, 1.0), reasons


def _rarity_score(word: str, dictionary: Dictionary) -> float:
    """Proxy rarity: words matched only in a *flavor* list (crypto/gaming/
    tech/slang/brand) score higher than everyday generic words, since
    they're more distinctive as handles."""
    cats = dictionary.categories_of(word)
    if not cats:
        return 0.5  # unknown word — neutral-ish, AI stage may weigh in
    if cats == {"generic_word"}:
        return 0.35
    if "generic_word" in cats and len(cats) == 1:
        return 0.35
    # distinctive-only categories
    distinctive = cats - {"generic_word", "name"}
    if distinctive:
        return 0.8
    return 0.5


def _numbers_penalty(username: str) -> tuple[float, list[str]]:
    digits = sum(c.isdigit() for c in username)
    if digits == 0:
        return 0.0, []
    ratio = digits / len(username)
    if ratio >= 0.5:
        return 0.9, ["excessive numeric characters"]
    if ratio >= 0.3:
        return 0.4, ["several numeric characters"]
    return 0.1, []


def _spammy_penalty(username: str) -> tuple[float, list[str]]:
    for pat in SPAMMY_PATTERNS[:2]:  # hard spam signals only
        if pat.match(username.lower()):
            return 1.0, ["spam-like pattern"]
    return 0.0, []


def _offensive_penalty(username: str) -> tuple[float, list[str]]:
    if username.lower() in OFFENSIVE_TERMS:
        return 1.0, ["flagged as potentially offensive"]
    return 0.0, []


def score_username(
    username: str,
    dictionary: Dictionary,
    scoring_cfg: dict[str, Any],
) -> ScoreResult:
    uname = username.lstrip("@").lower()
    weights = scoring_cfg["weights"]

    if len(uname) > scoring_cfg.get("max_length_considered", 32):
        return ScoreResult(
            username=username, total_score=0, breakdown={}, category="unknown",
            matched_word=None, reasons=["exceeds max considered length"], tier="ignore",
        )

    reasons: list[str] = []
    breakdown: dict[str, float] = {}

    # --- length ---
    length_pts = _length_score(len(uname), scoring_cfg)
    breakdown["length"] = length_pts

    # --- dictionary match ---
    matched_word = uname if uname in dictionary else None
    dict_pts = 0.0
    category = "unknown"
    if matched_word:
        dict_pts = weights["dictionary_match"]
        category = dictionary.category_of(matched_word) or "unknown"
        reasons.append(f"exact dictionary match ({category})")
    else:
        # try compound / substring match against known short words (only
        # for names up to 8 chars, to keep this cheap and meaningful)
        if len(uname) <= 8:
            for split_at in range(2, len(uname) - 1):
                left, right = uname[:split_at], uname[split_at:]
                if left in dictionary and right in dictionary:
                    dict_pts = weights["dictionary_match"] * 0.7
                    category = dictionary.category_of(left) or dictionary.category_of(right) or "unknown"
                    matched_word = f"{left}+{right}"
                    reasons.append(f"compound of two dictionary words ({left} + {right})")
                    break
    breakdown["dictionary_match"] = dict_pts

    # --- pronounceability ---
    pron_ratio = _pronounceability_score(uname)
    pron_pts = pron_ratio * weights["pronounceability"]
    breakdown["pronounceability"] = pron_pts
    if pron_ratio >= 0.8:
        reasons.append("easy to pronounce")
    elif pron_ratio <= 0.3:
        reasons.append("hard to pronounce")

    # --- pattern quality ---
    pattern_ratio, pattern_reasons = _pattern_quality_score(uname)
    pattern_pts = pattern_ratio * weights["pattern_quality"]
    breakdown["pattern_quality"] = pattern_pts
    reasons.extend(pattern_reasons)

    # --- rarity ---
    rarity_ratio = _rarity_score(uname, dictionary)
    rarity_pts = rarity_ratio * weights["rarity"]
    breakdown["rarity"] = rarity_pts

    # --- semantic meaning (heuristic proxy; refined by AI later) ---
    # proxy: has a dictionary match at all + is a single recognizable token
    semantic_ratio = 0.0
    if matched_word and "+" not in matched_word:
        semantic_ratio = 1.0
    elif matched_word:
        semantic_ratio = 0.6
    semantic_pts = semantic_ratio * weights["semantic_meaning"]
    breakdown["semantic_meaning"] = semantic_pts

    # --- brandability ---
    brand_ratio = 0.0
    if uname.isalpha():
        brand_ratio += 0.4
    if len(uname) <= 6:
        brand_ratio += 0.3
    if pron_ratio >= 0.7:
        brand_ratio += 0.3
    brand_ratio = min(brand_ratio, 1.0)
    brand_pts = brand_ratio * weights["brandability"]
    breakdown["brandability"] = brand_pts

    # --- category relevance ---
    cat_priority = scoring_cfg.get("category_priority", {})
    max_priority = max(cat_priority.values()) if cat_priority else 1.0
    cat_mult = 1.0
    if category != "unknown":
        cat_mult = cat_priority.get(category, cat_priority.get("generic_word", 1.0))
    # scale category weight by how prioritized this category is, normalized
    # against the highest-priority category configured (e.g. crypto)
    category_pts = (weights["category_relevance"] if matched_word else 0.0) * (cat_mult / max_priority)
    breakdown["category_relevance"] = category_pts

    raw_total = sum(breakdown.values())

    # --- penalties ---
    penalties = []
    num_pen, num_reasons = _numbers_penalty(uname)
    spam_pen, spam_reasons = _spammy_penalty(uname)
    off_pen, off_reasons = _offensive_penalty(uname)
    penalties.extend([(num_pen, num_reasons), (spam_pen, spam_reasons), (off_pen, off_reasons)])

    penalty_factor = 1.0
    penalized = False
    for pen, pen_reasons in penalties:
        if pen > 0:
            penalty_factor -= pen * 0.5  # each strong penalty can cut up to 50%
            reasons.extend(pen_reasons)
            penalized = True
    penalty_factor = max(0.0, penalty_factor)

    total = raw_total * penalty_factor
    total = max(0.0, min(100.0, total))

    thresholds = scoring_cfg["thresholds"]
    if total >= thresholds["exceptional"]:
        tier = "exceptional"
    elif total >= thresholds["very_strong"]:
        tier = "very_strong"
    elif total >= thresholds["good"]:
        tier = "good"
    elif total >= thresholds["interesting"]:
        tier = "interesting"
    else:
        tier = "ignore"

    return ScoreResult(
        username=uname,
        total_score=round(total, 1),
        breakdown={k: round(v, 2) for k, v in breakdown.items()},
        category=category,
        matched_word=matched_word,
        reasons=reasons,
        penalized=penalized,
        tier=tier,
    )
