"""
Ties the whole pipeline together for one scan cycle:

  auction data (source adapter)
    -> normalize (lowercase, strip @)
    -> dedupe (per cycle, via a seen-set; DB upsert also dedupes long-term)
    -> length/pattern filter (config.filters)
    -> dictionary lookup + deterministic scoring (scanner.scorer)
    -> AI semantic check, only for candidates above the AI threshold
    -> final score = blend of deterministic + AI
    -> persist to SQLite
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from .ai_analyzer import AiAnalyzer
from .config import Config
from .db import ScannerDB
from .dictionary import Dictionary
from .scorer import score_username
from .sources import Listing, build_source

logger = logging.getLogger(__name__)


def _passes_filters(username: str, filters_cfg: dict[str, Any]) -> bool:
    length = len(username)
    if length < filters_cfg.get("min_length", 3):
        return False
    if length > filters_cfg.get("max_length", 32):
        return False
    excluded = set(filters_cfg.get("excluded_categories", []))
    if excluded:
        # category-based exclusion happens after dictionary lookup in the
        # caller; this early check only handles length for speed
        pass
    return True


def _blend_scores(det_score: float, ai_semantic_score: float | None, ai_has_meaning: bool | None) -> float:
    """Deterministic score dominates; AI refines it. If AI found no real
    meaning where the deterministic pass guessed one (e.g. a compound-word
    false positive), pull the score down rather than trusting the heuristic."""
    if ai_semantic_score is None:
        return det_score
    if ai_has_meaning is False:
        # AI disagrees there's real meaning — heavily discount
        return min(det_score, ai_semantic_score) * 0.6
    return round((det_score * 0.55) + (ai_semantic_score * 0.45), 1)


async def run_scan_cycle(
    config: Config,
    dictionary: Dictionary,
    db: ScannerDB,
    ai: AiAnalyzer | None,
) -> int:
    """Runs one full scan cycle. Returns the number of listings examined."""
    source = build_source(config.source)
    filters_cfg = config.filters
    scoring_cfg = config.scoring
    ai_cfg = config.ai_analysis

    seen_this_cycle: set[str] = set()
    examined = 0
    ai_calls_this_cycle = 0
    max_ai_calls = ai_cfg.get("max_candidates_per_cycle", 15)
    min_score_for_ai = ai_cfg.get("min_deterministic_score_for_ai", 55)

    try:
        async for listing in source.fetch_listings(config.source.get("max_pages_per_scan", 20)):
            examined += 1
            uname = listing.username.lower().lstrip("@")
            if uname in seen_this_cycle:
                continue
            seen_this_cycle.add(uname)

            if not _passes_filters(uname, filters_cfg):
                continue

            result = score_username(uname, dictionary, scoring_cfg)

            if result.category in set(filters_cfg.get("excluded_categories", [])):
                continue

            ignore_threshold = scoring_cfg["thresholds"]["interesting"]
            if result.total_score < ignore_threshold:
                # below "interesting" — don't even bother persisting/AI-checking
                continue

            ai_result = None
            if ai and ai.enabled and result.total_score >= min_score_for_ai and ai_calls_this_cycle < max_ai_calls:
                ai_result = await ai.analyze(
                    uname, {"matched_word": result.matched_word, "category": result.category}
                )
                ai_calls_this_cycle += 1

            final_score = _blend_scores(
                result.total_score,
                ai_result.semantic_score if ai_result else None,
                ai_result.has_meaning if ai_result else None,
            )
            thresholds = scoring_cfg["thresholds"]
            if final_score >= thresholds["exceptional"]:
                final_tier = "exceptional"
            elif final_score >= thresholds["very_strong"]:
                final_tier = "very_strong"
            elif final_score >= thresholds["good"]:
                final_tier = "good"
            elif final_score >= thresholds["interesting"]:
                final_tier = "interesting"
            else:
                final_tier = "ignore"

            if final_tier == "ignore":
                continue

            db.upsert_candidate({
                "username": uname,
                "length": len(uname),
                "auction_status": listing.auction_status,
                "price_ton": listing.price_ton,
                "price_usd": listing.price_usd,
                "time_left": listing.time_left,
                "listing_url": listing.listing_url,
                "det_score": result.total_score,
                "det_tier": result.tier,
                "det_category": result.category,
                "det_matched_word": result.matched_word,
                "det_reasons": "; ".join(result.reasons),
                "ai_score": ai_result.semantic_score if ai_result else None,
                "ai_meaning": ai_result.meaning if ai_result else None,
                "ai_why": ai_result.why if ai_result else None,
                "final_score": final_score,
                "final_tier": final_tier,
                "raw_json": None,
            })
    finally:
        await source.close()

    logger.info("Scan cycle complete: %d listings examined, %d AI calls used.", examined, ai_calls_this_cycle)
    return examined
