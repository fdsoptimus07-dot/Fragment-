"""Shared Telegram message formatting — used by both the live-polling bot
(scanner/bot/telegram_bot.py) and the one-shot notify script used in the
GitHub Actions workflow (scripts/scan_and_notify.py), so the two never
drift out of sync."""

from __future__ import annotations

TIER_EMOJI = {
    "exceptional": "🔥",
    "very_strong": "⭐",
    "good": "🟢",
    "interesting": "🔹",
}


def fmt_full_card(row) -> str:
    emoji = TIER_EMOJI.get(row["final_tier"], "🔹")
    meaning = row["ai_meaning"] or row["det_matched_word"] or "—"
    why = row["ai_why"] or (row["det_reasons"] or "").replace('"', "")
    auction_bits = []
    if row["price_ton"]:
        auction_bits.append(f"{row['price_ton']:.0f} TON")
    if row["price_usd"]:
        auction_bits.append(f"(${row['price_usd']:.0f})")
    if row["time_left"]:
        auction_bits.append(f"· {row['time_left']}")
    auction_line = " ".join(auction_bits) if auction_bits else (row["auction_status"] or "unknown")

    return (
        f"{emoji} New candidate\n\n"
        f"Username: @{row['username']}\n"
        f"Length: {row['length']}\n"
        f"Meaning: {meaning}\n"
        f"Category: {row['det_category']}\n"
        f"Score: {row['final_score']:.0f}/100\n"
        f"Auction: {auction_line}\n"
        f"Why: {why}"
    )


def fmt_compact_line(row) -> str:
    emoji = TIER_EMOJI.get(row["final_tier"], "🔹")
    return f"{emoji} {row['final_score']:.0f} — @{row['username']}"
