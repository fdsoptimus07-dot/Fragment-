"""
Loads all configured wordlist files into a single indexed structure so
lookups are O(1) regardless of how many source lists are configured.

Each source file's *filename* determines its category (see CATEGORY_MAP),
which the scorer later uses for category-relevance bonuses (crypto, tech,
gaming, finance, brand, name, generic word).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

CATEGORY_MAP = {
    "wordlist_en.txt": "generic_word",
    "abbreviations.txt": "abbreviation",
    "slang_internet.txt": "slang",
    "tech_terms.txt": "tech",
    "gaming_terms.txt": "gaming",
    "finance_crypto_terms.txt": "crypto",
    "common_names.txt": "name",
    "geo_abbreviations.txt": "geo",
    "brands_terms.txt": "brand",
}

# Category priority order when a term appears in multiple lists —
# the more "distinctive" category wins for display purposes.
CATEGORY_RANK = [
    "crypto", "tech", "gaming", "finance", "brand",
    "abbreviation", "geo", "name", "slang", "generic_word",
]


@dataclass
class Dictionary:
    # word -> best (most distinctive) category
    word_category: dict[str, str] = field(default_factory=dict)
    # word -> set of ALL categories it appears in (for scoring nuance)
    word_categories: dict[str, set[str]] = field(default_factory=dict)
    # frequency-ish rarity proxy: shorter source lists = "rarer" flavor terms
    # (not true corpus frequency, but good enough as a deterministic signal
    # without needing an external frequency corpus)
    total_words: int = 0

    def __contains__(self, word: str) -> bool:
        return word.lower() in self.word_category

    def category_of(self, word: str) -> str | None:
        return self.word_category.get(word.lower())

    def categories_of(self, word: str) -> set[str]:
        return self.word_categories.get(word.lower(), set())

    def is_common_word(self, word: str) -> bool:
        cats = self.categories_of(word)
        return "generic_word" in cats or "name" in cats


def _category_for_path(path: Path) -> str:
    return CATEGORY_MAP.get(path.name, "generic_word")


def load_dictionary(paths: list[Path]) -> Dictionary:
    d = Dictionary()
    for path in paths:
        if not path.exists():
            continue
        category = _category_for_path(path)
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                word = line.strip().lower()
                if not word or word.startswith("#"):
                    continue
                d.total_words += 1
                d.word_categories.setdefault(word, set()).add(category)
                existing = d.word_category.get(word)
                if existing is None:
                    d.word_category[word] = category
                else:
                    # keep the more distinctive category as the "primary" one
                    if CATEGORY_RANK.index(category) < CATEGORY_RANK.index(existing):
                        d.word_category[word] = category
    return d
