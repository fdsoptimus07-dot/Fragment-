"""Loads and validates config.yaml into a simple typed structure."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent


def _abs(path_str: str) -> Path:
    p = Path(path_str)
    return p if p.is_absolute() else (REPO_ROOT / p)


@dataclass
class Config:
    raw: dict[str, Any]
    path: Path

    # ---- convenience accessors -------------------------------------
    @property
    def source(self) -> dict[str, Any]:
        return self.raw["source"]

    @property
    def database_path(self) -> Path:
        return _abs(self.raw["database"]["path"])

    @property
    def dictionary_sources(self) -> list[Path]:
        return [_abs(p) for p in self.raw["dictionary"]["sources"]]

    @property
    def scoring(self) -> dict[str, Any]:
        return self.raw["scoring"]

    @property
    def ai_analysis(self) -> dict[str, Any]:
        return self.raw["ai_analysis"]

    @property
    def notifications(self) -> dict[str, Any]:
        return self.raw["notifications"]

    @property
    def filters(self) -> dict[str, Any]:
        return self.raw["filters"]

    @property
    def telegram_bot_token(self) -> str | None:
        return os.environ.get("FRAGMENT_SCANNER_BOT_TOKEN")

    @property
    def telegram_chat_id(self) -> str | None:
        return os.environ.get("FRAGMENT_SCANNER_CHAT_ID")

    @property
    def anthropic_api_key(self) -> str | None:
        return os.environ.get("ANTHROPIC_API_KEY")


def load_config(path: str | Path = REPO_ROOT / "config" / "config.yaml") -> Config:
    path = Path(path)
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    return Config(raw=raw, path=path)
