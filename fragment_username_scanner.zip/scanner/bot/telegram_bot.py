"""
Telegram bot layer. Uses `python-telegram-bot` (async) for command handling
and message sending. Two responsibilities:

  1. Background notifier — periodically (or immediately, per config) pushes
     new high-scoring candidates to the configured chat.
  2. Commands — /scan triggers an on-demand scan cycle and reports results;
     /top N returns the N highest-scoring candidates currently in the DB.
"""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

from ..db import ScannerDB
from ..notify_formatting import fmt_compact_line, fmt_full_card

logger = logging.getLogger(__name__)


TIER_EMOJI = {
    "exceptional": "🔥",
    "very_strong": "⭐",
    "good": "🟢",
    "interesting": "🔹",
}


def _fmt_full_card(row) -> str:
    return fmt_full_card(row)


def _fmt_compact_line(row) -> str:
    return fmt_compact_line(row)


class ScannerBot:
    def __init__(
        self,
        token: str,
        chat_id: str,
        db: ScannerDB,
        notif_cfg: dict[str, Any],
        run_scan_cycle: Callable[[], Awaitable[int]],
    ):
        self.token = token
        self.chat_id = chat_id
        self.db = db
        self.notif_cfg = notif_cfg
        self.run_scan_cycle = run_scan_cycle
        self.app: Application = Application.builder().token(token).build()
        self.app.add_handler(CommandHandler("scan", self._cmd_scan))
        self.app.add_handler(CommandHandler("top", self._cmd_top))
        self.app.add_handler(CommandHandler("start", self._cmd_start))

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await update.message.reply_text(
            "Fragment username auction scanner online.\n"
            "/scan — run a scan cycle now\n"
            "/top N — show the N highest-scoring candidates (default 10)"
        )

    async def _cmd_scan(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await update.message.reply_text("Scanning current Fragment auction listings…")
        try:
            found = await self.run_scan_cycle()
        except Exception as e:
            logger.exception("scan cycle failed")
            await update.message.reply_text(f"Scan failed: {e}")
            return
        min_score = self.notif_cfg["min_score_to_notify"]
        rows = self.db.get_top(limit=self.notif_cfg["max_results_per_notification"], min_score=min_score)
        if not rows:
            await update.message.reply_text(f"Scan complete ({found} listings checked). No candidates above threshold.")
            return
        await update.message.reply_text(f"Scan complete ({found} listings checked). Top results:")
        await self._send_results(update.effective_chat.id, rows)

    async def _cmd_top(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        n = 10
        if context.args:
            try:
                n = max(1, min(int(context.args[0]), 50))
            except ValueError:
                pass
        rows = self.db.get_top(limit=n, min_score=0.0)
        if not rows:
            await update.message.reply_text("No candidates tracked yet — try /scan first.")
            return
        await self._send_results(update.effective_chat.id, rows, force_compact=True)

    async def _send_results(self, chat_id: int | str, rows: list, force_compact: bool = False) -> None:
        threshold = self.notif_cfg.get("list_mode_threshold", 5)
        if force_compact or len(rows) > threshold:
            lines = [_fmt_compact_line(r) for r in rows]
            await self.app.bot.send_message(chat_id=chat_id, text="\n".join(lines))
        else:
            for row in rows:
                await self.app.bot.send_message(chat_id=chat_id, text=_fmt_full_card(row))

    async def notify_new_candidates(self) -> None:
        """Called by the background poller after each scan cycle."""
        min_score = self.notif_cfg["min_score_to_notify"]
        max_results = self.notif_cfg["max_results_per_notification"]
        rows = self.db.get_unnotified_above(min_score)[:max_results]
        if not rows:
            return
        await self._send_results(self.chat_id, rows)
        self.db.mark_notified([(r["username"], r["final_score"]) for r in rows])

    async def run(self) -> None:
        async with self.app:
            await self.app.start()
            await self.app.updater.start_polling()
            logger.info("Telegram bot polling started.")
            # keep running until cancelled by the orchestrator
            import asyncio
            while True:
                await asyncio.sleep(3600)
