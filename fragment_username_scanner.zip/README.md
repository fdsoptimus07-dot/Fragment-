# Fragment Username Auction Scanner

Monitors Fragment's publicly viewable Telegram-username marketplace,
filters listings for meaningful (not random-looking) usernames, scores
them deterministically, runs a cheap AI semantic check only on the
promising candidates, and pushes results to Telegram.

## Important: there is no official Fragment API

Fragment (fragment.com) does not publish a documented, authorized public
API for auction data. The included `fragment_public_html` source adapter
fetches the same public, unauthenticated pages a browser would load
(`fragment.com/usernames?...`) at a conservative, configurable rate. It
does **not** log in, solve captchas, hit private/internal endpoints, or
bypass any rate limiting — see the big comment at the top of
`scanner/sources/fragment_public_html.py` for the exact guarantees and
limitations.

Because it depends on Fragment's page markup rather than a stable API,
**expect to need to update the parsing regexes in that file** if Fragent
changes its page layout — the adapter is written defensively and fails
safe (returns nothing) rather than guessing, but it can't self-heal
against arbitrary markup changes.

If you have (or later license) a proper data feed, implement
`scanner/sources/base.py`'s `AuctionSource` interface for it and switch
`source.adapter` in `config.yaml` — nothing else in the pipeline needs to
change.

## Architecture

```
auction data (source adapter)
  -> normalize (lowercase, strip @)
  -> dedupe
  -> length/pattern filter
  -> dictionary lookup (scanner/dictionary.py)
  -> deterministic scoring (scanner/scorer.py)
  -> AI semantic check — ONLY for candidates that already cleared a
     deterministic score threshold (scanner/ai_analyzer.py)
  -> blended final score
  -> SQLite persistence (scanner/db.py)
  -> Telegram notification / /scan / /top (scanner/bot/telegram_bot.py)
```

Every stage is a separate module so you can, e.g., swap the scoring
weights, plug in a bigger dictionary, or replace the data source without
touching anything else.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in your bot token, chat id, (optional) Anthropic key
```

Load the env vars however you prefer (`python-dotenv`, `direnv`,
`export $(cat .env | xargs)`, systemd `EnvironmentFile=`, etc.) before
running.

### Dictionary

`data/wordlist_en.txt` ships with a curated ~1,300-word starter list
covering common short/medium English words — enough to run and test the
pipeline immediately.

For production use, swap in a comprehensive list. There's no official
"Google dictionary" API or bulk dataset to pull from — Google's `define:`
box in Search is just a UI over third-party snippets, not something
exposed for bulk/programmatic use. The standard free alternative is the
[dwyl/english-words](https://github.com/dwyl/english-words) list
(~370k+ words, MIT licensed). A helper script is included:

```bash
python scripts/fetch_full_wordlist.py
```

This downloads it and rewrites `data/wordlist_en.txt` in the same
one-word-per-line format the loader already expects — nothing else
changes. (A Linux system dictionary package like `wamerican-large`, or
`dictionaryapi.dev` for live per-word definition lookups on borderline
candidates, are other options if you'd rather go that route.)

The other `data/*.txt` files
(abbreviations, slang, tech/gaming/crypto terms, names, geo codes,
brands) are also hand-curated starter sets — extend them freely; the
loader (`scanner/dictionary.py`) just needs one word per line and infers
category from the filename (see `CATEGORY_MAP`).

### Config

All tunables live in `config/config.yaml`:
- scoring weights and length bonuses (3/4/5-char usernames weighted far
  above longer ones, per your spec, but nothing is EXCLUDED just for
  being longer if it scores well on meaning)
- score tier thresholds (exceptional/very_strong/good/interesting/ignore)
- AI trigger threshold and per-cycle cap
- notification frequency, batching, thresholds
- crawl politeness settings (delay, concurrency, page cap)

## Running on GitHub Actions (free, scheduled, no live commands)

This is the recommended free path if you don't have an always-on server:
GitHub Actions runs `scripts/scan_and_notify.py` on a schedule, pushes any
new above-threshold candidates to Telegram, and commits the scanner's
"already notified" state back into the repo so it persists between runs
(Actions gives you a fresh disposable machine every time otherwise).

**Trade-off:** this mode has no `/scan` or `/top` commands — those need a
process that's listening continuously, which a scheduled job isn't. You
get the periodic Telegram push notifications only. `main.py` (the
always-on bot with commands, below) still works fine if you ever move to
a host that can run it continuously.

### Setup

1. Push this project to a new GitHub repo (public or private — Actions
   minutes are free either way for this workload).
2. In the repo: **Settings → Secrets and variables → Actions → New
   repository secret**, add two secrets:
   - `FRAGMENT_SCANNER_BOT_TOKEN` — your bot token from @BotFather
   - `FRAGMENT_SCANNER_CHAT_ID` — e.g. `@yourchannelname` for a public
     channel (make sure the bot is an admin of that channel first)
3. Never put real credentials in `.env` inside the repo — `.gitignore`
   already excludes it, and the workflow reads secrets from GitHub, not
   from a file.
4. That's it — `.github/workflows/scan.yml` runs every 15 minutes
   automatically. Trigger one manually any time via the **Actions** tab →
   *Fragment Username Scanner* → **Run workflow**.

### Notes

- GitHub disables scheduled workflows automatically after **60 days with
  no repository activity** — a manual run from the Actions tab, or any
  push, re-enables it.
- Scheduled cron times are best-effort on GitHub's side; expect the
  occasional few-minutes delay during platform load. Don't rely on it for
  second-level precision.
- The workflow commits `db/scanner.sqlite3` back on every run that finds
  new candidates, so your git history will show small periodic state
  commits — that's expected and how it avoids re-notifying the same
  username.

## Running (always-on host, with live /scan and /top commands)

```bash
# one-off scan, prints results to stdout, no bot needed
python main.py --scan-once

# full run: Telegram bot (/scan, /top) + background polling loop
python main.py
```

## Telegram commands

- `/scan` — run a scan cycle immediately and report results
- `/top N` — show the N highest-scoring candidates currently tracked
  (default 10, max 50)

## Notification format

Full card (used when a batch is small):
```
🔥 New candidate

Username: @example
Length: 7
Meaning: Example
Category: Dictionary word
Score: 86/100
Auction: 1200 TON ($1540) · 6 hours left
Why: Short, recognizable English word and highly brandable.
```

Compact list mode (used for larger batches or `/top`):
```
🔥 96 — @abc
⭐ 91 — @word
⭐ 87 — @tech
🟢 76 — @name
```

## Notes on scoring honesty

Scores are a **screening/relevance signal only** — they describe how
meaningful, brandable, and pattern-strong a username is. They are never
a price or resale prediction, and the bot's output deliberately avoids
any language implying a guaranteed sale value.
